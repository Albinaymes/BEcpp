#ifndef TOUCHSENSOR_H
#define TOUCHSENSOR_H


class TouchSensor  {
public:
    TouchSensor();  
    ~TouchSensor(); 
    int readValue() const;

   
};

#endif // TOUCHSENSOR_H
